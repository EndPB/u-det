# h2_stacad_alignment_v1

这是从本地 STACAD-v2 构建的紧凑多语言同任务对齐集。每个任务保留同一 human 文件的 7 个 generator paraphrase，使用原始 file-level split。

- `core.jsonl`：每个模型一行，包含代码和 family/generator 元数据。
- `task_index.jsonl`：每个任务一行，包含 human anchor 和任务信息。
- `pair_index.jsonl`：同任务跨 generator 对照 pair。
- `summary.json` / `split_manifest.json`：计数与协议。

这组 7 个 generator 各自属于不同厂商，因此 pair 不是 H2 的同家族正对；它用于多语言语义控制、任务中心化和外部验证。H2 正对仍应来自 LLM-CodeGen/AuthorBench 的 `same_family_cross_generator`。
